package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.FeignServiceUtil;
import com.example.demo.entity.Book;
import com.example.demo.entity.BookResponse;
import com.example.demo.entity.Person;
import com.example.demo.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private FeignServiceUtil feignServiceUtil;

	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}
	
	public List<Person> getAllPersons(){
		return feignServiceUtil.getAllPersons();
	}

	public List<BookResponse> getAllBookPerson() {
		List<BookResponse> bookResponses = new ArrayList<BookResponse>();
		BookResponse book = new BookResponse();
		List<Book> books = (List<Book>) bookRepository.findAll();
		List<Person> persons = (List<Person>) feignServiceUtil.getAllPersons();

		for (Book book2 : books) {
			book = new BookResponse();
			book.setId(book2.getId());
			book.setAuthor(book2.getAuthor());
			book.setTitle(book2.getTitle());
			book.setPersons(persons);
			bookResponses.add(book);
		}

		return bookResponses;
	}

	public Optional<Book> getBookById(Long id) {
		return bookRepository.findById(id);
	}

	public Book createBook(Book book) {
		return bookRepository.save(book);
	}

	public Book updateBook(Long id, Book updatedBook) {
		Book existingBook = bookRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Book not found with id: " + id));
		existingBook.setTitle(updatedBook.getTitle());
		existingBook.setAuthor(updatedBook.getAuthor());
		return bookRepository.save(existingBook);
	}

	public void deleteBook(Long id) {
		bookRepository.deleteById(id);
	}

}