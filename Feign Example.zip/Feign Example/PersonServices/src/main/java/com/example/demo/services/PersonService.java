package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Person;
import com.example.demo.repository.PersonRepository;

@Service
public class PersonService {

	@Autowired
	private PersonRepository personRepository;

	public List<Person> getAllPersons() {
		return personRepository.findAll();
	}

	public Optional<Person> getPersonById(Long id) {
		return personRepository.findById(id);
	}

	public Person createPerson(Person person) {
		return personRepository.save(person);
	}

	public Person updatePerson(Long id, Person updatedPerson) {
		Person existingPerson = personRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Person not found with id: " + id));
		existingPerson.setName(updatedPerson.getName());
		existingPerson.setAge(updatedPerson.getAge());
		return personRepository.save(existingPerson);
	}

	public void deletePerson(Long id) {
		personRepository.deleteById(id);
	}
}